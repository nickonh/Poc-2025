@echo off
REM ============================================================
REM  descargar.bat - Descarga archivo.zip desde servidor Flask
REM  Cambia URL por la de ngrok si usas tunnel, ej:
REM    set URL=https://hesitancy-decompose-unending.ngrok-free.dev/descargar
REM ============================================================
 
set URL=https://hesitancy-decompose-unending.ngrok-free.dev/descargar
 
echo [INFO] Descargando desde: %URL%
echo.
 
powershell -Command "Invoke-WebRequest -Uri '%URL%'"
 
if %ERRORLEVEL% == 0 (
    echo [OK] Descarga completada exitosamente.
) else (
    echo [ERROR] Fallo al descargar el archivo.
    echo [ERROR] Verifica que el servidor este activo y la URL sea correcta.
)
 
pause
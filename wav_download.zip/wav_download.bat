@echo off
REM ============================================================
REM  descargar.bat - Descarga archivo.zip desde servidor Flask
REM  Cambia URL por la de ngrok si usas tunnel, ej:
REM    set URL=https://hesitancy-decompose-unending.ngrok-free.dev/descargar
REM ============================================================
 
set URL=https://hesitancy-decompose-unending.ngrok-free.dev/descargar
set DESTINO=%~dp0archivo_descargado.zip
 
echo [INFO] Descargando desde: %URL%
echo [INFO] Guardando en:      %DESTINO%
echo.

powershell -Command "Invoke-WebRequest -Uri '%URL%' -OutFile '%DESTINO%'"
 
if %ERRORLEVEL% == 0 (
    echo [OK] Descarga completada exitosamente.
    echo [OK] Archivo guardado en: %DESTINO%
) else (
    echo [ERROR] Fallo al descargar el archivo.
    echo [ERROR] Verifica que el servidor este activo y la URL sea correcta.
)
 
pause